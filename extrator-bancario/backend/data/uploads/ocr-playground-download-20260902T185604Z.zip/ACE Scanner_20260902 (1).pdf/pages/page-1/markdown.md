02/02/2026, 15:53

Internet Banking Sicredi

Sicredi

Associado: ASSOCIACAO DE FAMILIARES PAIS E AMIGOS DAS PESSOAS COM DEFICIENCIA E ALTAS HABILIDADES AURORA DA VI

Cooperativa: 0116

Conta Corrente: 28241-8

Impresso em 02/02/2026 15:53:05

# Extrato

Dados referentes ao periodo 01/01/2026 a 31/01/2026.

[tbl-0.html](tbl-0.html)

1/2

https://ibp.sicredi.com.br/ib-view/extrato/form1.html?oidTrans=116