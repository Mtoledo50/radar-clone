02/02/2026, 15:53

Internet Banking Sicredi

Sicredi

Associado: ASSOCIACAO DE FAMILIARES PAIS E AMIGOS DAS PESSOAS COM DEFICIENCIA E ALTAS HABILIDADES AURORA DA VI

Cooperativa: 0116

Conta Corrente: 28241-8

Impresso em 02/02/2026 15:53:05

# Extrato

Dados referentes ao periodo 01/01/2026 a 31/01/2026.

[tbl-0.html](tbl-0.html)

1/2

https://ibp.sicredi.com.br/ib-view/extrato/form1.html?oidTrans=116

# Internet Banking Sicredi

[tbl-1.html](tbl-1.html)

Sicredi Fone 3003 4770 (Capitais e Regiões Metropolitanas)

0800 724 4770 (Demais Regiões)

SAC 0800 724 7220

Ouvidoria 0800 646 2519

https://ibnl.sicredi.com.br/ib-view/extrato/form/1.html?cidTrans=116

2/2